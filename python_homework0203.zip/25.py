phone_number = "010-1111-2222"
phone_number.replace('-','')
print(phone_number.replace('-',' '))