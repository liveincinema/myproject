print ((3 == 3) and (4 != 3))
결과는 true