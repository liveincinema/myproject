my_list = ["가", "나", "다", "라"]
for A in my_list[1:]:
    print(A)