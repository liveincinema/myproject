license_plate = "24가 2210"
print(license_plate[4], license_plate[5], license_plate[6], license_plate[7])
print(license_plate[4:])