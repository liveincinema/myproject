def print_coin():
    print('비트코인')
for i in range(100) :
    print_coin()