def print_coin():
    print('비트코인')