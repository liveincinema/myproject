s = "hello"
t = "python"
print(s + '!' + t)