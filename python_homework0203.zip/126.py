portfolio = ["SK하이닉스", "삼성전자", "LG전자"]
for b in portfolio:
    print(b + " 보유중")