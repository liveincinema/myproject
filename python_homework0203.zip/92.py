print(3 == 5)
결과는 false