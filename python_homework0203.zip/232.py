def print_coin():
    print('비트코인')
print_coin()