nums = [1, 2, 3, 4, 5]
AVG = sum(nums)/len(nums)
print(AVG)